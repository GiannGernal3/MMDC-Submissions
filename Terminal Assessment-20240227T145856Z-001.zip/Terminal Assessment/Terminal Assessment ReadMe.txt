Milestone 2:

1. You should have 8 jar files:
  - commons-collections4-4.1 ( Folder name: Apache POI)
  - poi 3.17 ( Folder name: Apache POI)
  - poi-ooxml-3.17 ( Folder name: Apache POI)
  - poi-ooxml-schemas-3.17 ( Folder name: Apache POI)
  - xmlbeans-2.6 ( Folder name: Apache POI)
  - commons-lang3- 3.12 ( Folder name: Commons-lang3-3.12)
  - jcalendar 3.14 ( Folder name: jcalendar)
  - openCSV 5.7.1 ( Location: main folder )

2. When you run the employeeApplication, a LogIn page will appear; you can see the details for the LogIn in the "Employee Username and Password" CSV.After logging in successfully, a jFrame will appear (employeeDetails.java file).

3. In the employeeDetails.java has 4 buttons and when you click those buttons: 
  - Insert Button: is for inserting the CSV file ( Name of the CSV: Motor PH Employee Data )
  - View Button: when you select a specific row in the jTable (where the Motor PH Employee Data.csv will be shown), the employee details from that selected row will be displayed on another jFrame.
  - Add Button: This is for adding new Employee, fill out the details and then click add; it will be added on the jTable and also in the CSV
  - Delete Button: is when you select a row from the jtable, it will delete the row from the table and CSV.

4. After selecting an employee and viewing the details, there's a jComboBox for the months. When you select a specific month it will display the employee's payroll.

5. In the payrollDetails ( number 3) there is an "Apply for Leave " Button, where if you clicked it, it will show the leave application feature.

6. In the leaveApplication, there is a jDateChooser where you can select dates (start and end of you leave) and comboBox for selecting the type of leave you going to apply. If you're done filling out those, then you click the submit button; a prompt will show that the was filed successfully. 

7. After filing a leave, it will appear on the jTable on the right, and you can click the specific leave application and approve it or decline it. The application that you need to select should have the same employee number to the one that filed it ( e.g. 10001 filed a leave and you should select the leave that 10001 filed. If you approve/decline a different leave application, a message will appear " Employee number don't match).
   If you click the Approve button, a message will appear that " Leave Application (number) Approved" and it will automatically change the remaining credits of that employee. And if Declined that, "Leave Application (number) Declined" the status of the leave will be changed and also the CSV. The CSV for credits is named "leavecredits" and for the record it is "Leave Record"; These csv files are in the folder for Milestone 2.

